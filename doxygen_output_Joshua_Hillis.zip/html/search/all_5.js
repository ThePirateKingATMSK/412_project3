var searchData=
[
  ['loadbalancer_0',['LoadBalancer',['../class_load_balancer.html',1,'LoadBalancer'],['../class_load_balancer.html#affc9dc4c283d20bacc85a66cb721fd19',1,'LoadBalancer::LoadBalancer(int numServers, int timeLeft)']]],
  ['logmessage_1',['logMessage',['../class_load_balancer.html#a532755d49338c513ec2f12fd220fb696',1,'LoadBalancer']]]
];
