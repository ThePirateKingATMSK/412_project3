var searchData=
[
  ['ip_0',['ip',['../class_request.html#a66716d1edbd72c3fd494e5f50a9ad0f1',1,'Request']]],
  ['isused_1',['isUsed',['../class_server.html#a4b3a63b188e1acabc9943c35114fcb28',1,'Server']]]
];
