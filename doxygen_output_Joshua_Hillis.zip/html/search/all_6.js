var searchData=
[
  ['numrejections_0',['numRejections',['../class_load_balancer.html#a7ee50bb5e2f30a9e570056e61d9bd469',1,'LoadBalancer']]],
  ['numservers_1',['numServers',['../class_load_balancer.html#acaa0f5fe812ec75c7d177c0fb8b181fc',1,'LoadBalancer']]]
];
