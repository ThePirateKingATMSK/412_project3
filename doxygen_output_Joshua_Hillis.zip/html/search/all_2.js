var searchData=
[
  ['currentrequest_0',['currentRequest',['../class_server.html#a14f465a2d5deb94625e2666e23eca1c6',1,'Server']]],
  ['cyclesleft_1',['cyclesLeft',['../class_load_balancer.html#aaf170dd570e712316397906786f30400',1,'LoadBalancer::cyclesLeft'],['../class_server.html#a7fc56e6697b29cac608beb9ef9d2e141',1,'Server::cyclesLeft']]]
];
