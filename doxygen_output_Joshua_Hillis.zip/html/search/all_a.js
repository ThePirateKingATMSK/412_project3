var searchData=
[
  ['server_0',['Server',['../class_server.html',1,'Server'],['../class_server.html#a378f0593f288fa4769c1752438994de7',1,'Server::Server(int serverId)']]],
  ['serverid_1',['serverId',['../class_server.html#ab5cb18099fbb4d4d459ddf58ee8ae55e',1,'Server']]],
  ['serveridcounter_2',['serverIdCounter',['../class_load_balancer.html#adc86d6d1945ec57f4aafb45f60c4215e',1,'LoadBalancer']]],
  ['serverlist_3',['serverList',['../class_load_balancer.html#a1c42b8eb6167de6dd9486d946bbf78f4',1,'LoadBalancer']]]
];
