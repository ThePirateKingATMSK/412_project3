var searchData=
[
  ['ip_0',['ip',['../class_request.html#a66716d1edbd72c3fd494e5f50a9ad0f1',1,'Request']]],
  ['isblocked_1',['IsBlocked',['../class_load_balancer.html#adfd847a1159112ff600cb3bb62db3073',1,'LoadBalancer']]],
  ['isused_2',['isUsed',['../class_server.html#a4b3a63b188e1acabc9943c35114fcb28',1,'Server']]]
];
